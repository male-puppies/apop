local se = require('se')
local redis = require('redis')
local cjson = require('cjson')

function test_blpop()
	local r, err = redis.new("tcp://127.0.0.1:6379", {
		read_timeout = 6
	})
	assert(not err, err)

	local err = r:connect()
	assert(not err, err)

	while true do
		local res, err = r:call('blpop', 'list', '3')
		if err == 'TIMEOUT' then
			print('redis connection timeout')
			break
		end
		assert(not err, err)
		print(cjson.encode(res))
		if res and res[2] == 'quit' then
			break
		end
	end

	r:close()
end

function test_timer()
	for i = 1, 100 do
		print('timer: ', i)
		se.sleep(1)
	end
end

function main()
	se.go(test_timer)
	se.go(test_blpop)
end

se.run(main)